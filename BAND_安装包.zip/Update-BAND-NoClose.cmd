@echo off
setlocal
set "PACKAGE_DIR=%~dp0"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=powershell.exe"
set "APP_DIR=%PACKAGE_DIR%app"
if not exist "%APP_DIR%\Install-App.ps1" (
  if exist "%PACKAGE_DIR%Install-App.ps1" (
    set "APP_DIR=%PACKAGE_DIR%"
  )
)
if not exist "%APP_DIR%\Install-App.ps1" (
  echo Cannot find Install-App.ps1. Please extract the whole BAND package first.
  pause
  exit /b 1
)
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%APP_DIR%\Install-App.ps1" -NoClose -SkipWebView2
if errorlevel 1 pause
